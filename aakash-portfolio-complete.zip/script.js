/**
 * Aakash N - Portfolio Interactive Logic
 * Handles dynamic role typing, project filtering, modal previews,
 * clipboard copy, contact form handling, and navigation spy.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Set current year in footer
  const yearEl = document.getElementById('current-year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  /* --------------------------------------------------------------------------
     1. Dynamic Typewriter Effect for Hero Headline
     -------------------------------------------------------------------------- */
  const roles = [
    'Aspiring Data Analyst',
    'Data Scientist',
    'Machine Learning Enthusiast',
    'Python & SQL Developer',
    'AI Healthcare Innovator'
  ];

  const typewriterEl = document.getElementById('typewriter-text');
  let roleIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let typingSpeed = 100;

  function typeWriter() {
    if (!typewriterEl) return;

    const currentRole = roles[roleIndex];

    if (isDeleting) {
      typewriterEl.textContent = currentRole.substring(0, charIndex - 1);
      charIndex--;
      typingSpeed = 50;
    } else {
      typewriterEl.textContent = currentRole.substring(0, charIndex + 1);
      charIndex++;
      typingSpeed = 110;
    }

    if (!isDeleting && charIndex === currentRole.length) {
      isDeleting = true;
      typingSpeed = 1800; // Pause at complete word
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      roleIndex = (roleIndex + 1) % roles.length;
      typingSpeed = 400; // Pause before typing new word
    }

    setTimeout(typeWriter, typingSpeed);
  }

  typeWriter();

  /* --------------------------------------------------------------------------
     1b. Real-time Photo Uploader & Local Storage Sync
     -------------------------------------------------------------------------- */
  const profileUploadInput = document.getElementById('profile-upload-input');
  const btnTriggerUpload = document.getElementById('btn-trigger-upload');
  const btnResetPhoto = document.getElementById('btn-reset-photo');
  const heroProfileImg = document.getElementById('hero-profile-img');
  const aboutAvatars = document.querySelectorAll('.about-author-avatar');

  // Default to Aakash's real verified photo with cache-bust
  const defaultPhotoPath = 'assets/profile.jpg?v=' + Date.now();
  if (heroProfileImg) heroProfileImg.src = defaultPhotoPath;
  aboutAvatars.forEach(avatar => avatar.src = defaultPhotoPath);

  // Load user browser-uploaded custom photo if present
  const savedPhoto = localStorage.getItem('aakash_portfolio_avatar');
  if (savedPhoto && savedPhoto.startsWith('data:image/')) {
    if (heroProfileImg) heroProfileImg.src = savedPhoto;
    aboutAvatars.forEach(avatar => avatar.src = savedPhoto);
    if (btnResetPhoto) btnResetPhoto.style.display = 'inline-flex';
  }

  if (btnTriggerUpload && profileUploadInput) {
    btnTriggerUpload.addEventListener('click', () => {
      profileUploadInput.click();
    });
  }

  if (profileUploadInput) {
    profileUploadInput.addEventListener('change', (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;

      if (!file.type.startsWith('image/')) {
        showToast('Please select a valid image file (JPG, PNG, WebP)', false);
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target.result;
        if (heroProfileImg) heroProfileImg.src = dataUrl;
        aboutAvatars.forEach(avatar => avatar.src = dataUrl);

        try {
          localStorage.setItem('aakash_portfolio_avatar', dataUrl);
          if (btnResetPhoto) btnResetPhoto.style.display = 'inline-flex';
          showToast('Profile photo updated & saved successfully!');
        } catch (err) {
          showToast('Photo displayed for this session (image file is large for local cache)');
        }
      };

      reader.readAsDataURL(file);
    });
  }

  if (btnResetPhoto) {
    btnResetPhoto.addEventListener('click', () => {
      localStorage.removeItem('aakash_portfolio_avatar');
      const defaultPath = 'assets/profile.jpg';
      if (heroProfileImg) heroProfileImg.src = defaultPath;
      aboutAvatars.forEach(avatar => avatar.src = defaultPath);
      btnResetPhoto.style.display = 'none';
      if (profileUploadInput) profileUploadInput.value = '';
      showToast('Default profile portrait restored.');
    });
  }

  /* --------------------------------------------------------------------------
     2. Navbar Scroll Behavior & Active Section Spy
     -------------------------------------------------------------------------- */
  const navbar = document.getElementById('navbar');
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }

    // Scroll Spy
    let currentSectionId = '';
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 120;
      const sectionHeight = section.offsetHeight;
      if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
        currentSectionId = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${currentSectionId}`) {
        link.classList.add('active');
      }
    });
  });

  /* --------------------------------------------------------------------------
     3. Mobile Drawer Navigation
     -------------------------------------------------------------------------- */
  const mobileToggle = document.getElementById('mobile-toggle');
  const mobileClose = document.getElementById('mobile-close');
  const mobileDrawer = document.getElementById('mobile-drawer');
  const mobileLinks = document.querySelectorAll('.mobile-link');

  if (mobileToggle && mobileDrawer) {
    mobileToggle.addEventListener('click', () => {
      mobileDrawer.classList.add('open');
    });
  }

  if (mobileClose && mobileDrawer) {
    mobileClose.addEventListener('click', () => {
      mobileDrawer.classList.remove('open');
    });
  }

  mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (mobileDrawer) mobileDrawer.classList.remove('open');
    });
  });

  /* --------------------------------------------------------------------------
     4. Project Filtering System
     -------------------------------------------------------------------------- */
  const filterBtns = document.querySelectorAll('.filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filterValue = btn.getAttribute('data-filter');

      projectCards.forEach(card => {
        const category = card.getAttribute('data-category');
        if (filterValue === 'all' || category === filterValue) {
          card.style.display = 'flex';
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'scale(1)';
          }, 50);
        } else {
          card.style.opacity = '0';
          card.style.transform = 'scale(0.96)';
          setTimeout(() => {
            card.style.display = 'none';
          }, 200);
        }
      });
    });
  });

  /* --------------------------------------------------------------------------
     5. Project Case Study Modal Data & Handlers
     -------------------------------------------------------------------------- */
  const projectModal = document.getElementById('project-modal');
  const modalHeader = document.getElementById('modal-header');
  const modalBody = document.getElementById('modal-body');
  const modalClose = document.getElementById('modal-close');

  const projectDetails = {
    healthcare: {
      title: 'Transforming Healthcare with AI-Powered Disease Prediction',
      subtitle: 'Machine Learning • Predictive Diagnostics • Anna University Academic Work',
      content: `
        <p><strong>Overview:</strong> Medical diagnosis requires fast, highly accurate data evaluation. This project applies supervised machine learning algorithms to clinical patient datasets to predict potential disease onset at early stages.</p>
        
        <h4 style="color: #fff; margin: 1.25rem 0 0.5rem;">Key Engineering Highlights:</h4>
        <ul>
          <li><strong>Data Preprocessing & Cleansing:</strong> Handled missing values, outliers, and normalization to ensure unbiased model weights.</li>
          <li><strong>Feature Selection:</strong> Employed correlation analysis and recursive feature elimination to identify high-impact biomarker features.</li>
          <li><strong>Model Benchmarking:</strong> Trained and compared multiple classification algorithms (Logistic Regression, Random Forest, SVM) for sensitivity and recall metrics.</li>
          <li><strong>Clinical Decision Support:</strong> Structured the pipeline output to provide interpretable probabilities for physicians and patients.</li>
        </ul>

        <div style="background: rgba(255,255,255,0.04); padding: 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); margin-top: 1rem;">
          <strong style="color: #38bdf8;">Technologies Used:</strong> Python, Scikit-Learn, Pandas, NumPy, Matplotlib, Jupyter Notebook
        </div>
      `
    },
    cloud: {
      title: 'Intelligent Cloud Resource Monitoring and Cost Optimization Platform',
      subtitle: 'Python • Telemetry Analytics • FinOps Architecture (Ongoing)',
      content: `
        <p><strong>Overview:</strong> Modern organizations face massive cloud bill leakages caused by idle computing instances, orphaned block storage, and unoptimized resource sizing. This platform gathers performance metrics and predicts optimal capacity allocations.</p>
        
        <h4 style="color: #fff; margin: 1.25rem 0 0.5rem;">Key Engineering Highlights:</h4>
        <ul>
          <li><strong>Telemetry Tracking:</strong> Captures CPU utilization, memory thresholds, and storage I/O metrics across cloud instances.</li>
          <li><strong>Underutilization Heuristics:</strong> Algorithms detect patterns of workloads consistently operating below 15% threshold to recommend instance downsizing or auto-stopping.</li>
          <li><strong>Cost Reduction Forecasting:</strong> Computes estimated monthly dollar savings and displays actionable rightsizing reports.</li>
          <li><strong>Current Phase:</strong> Integrating automated alert triggers and predictive workload forecasting models.</li>
        </ul>

        <div style="background: rgba(255,255,255,0.04); padding: 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); margin-top: 1rem;">
          <strong style="color: #38bdf8;">Technologies Used:</strong> Python, Cloud Infrastructure APIs, Data Analysis, Performance Telemetry, Pandas
        </div>
      `
    },
    newborn: {
      title: 'Newborn Baby Monitoring & Hospital Visit Management System',
      subtitle: 'EDII-TN Nimirnthu Nil Hackathon Finalist • Healthcare Accessibility Portal',
      content: `
        <p><strong>Overview:</strong> Developed for the prestigious EDII-TN Hackathon, clearing three rigorous competitive rounds. Designed to streamline post-natal healthcare, immunization tracking, and hospital queues for mothers and pediatric doctors.</p>
        
        <h4 style="color: #fff; margin: 1.25rem 0 0.5rem;">Key Engineering Highlights:</h4>
        <ul>
          <li><strong>Dual Portal Architecture:</strong> Dedicated portals for parents (health cards, vaccine calendars) and doctors (queue management, visit history).</li>
          <li><strong>Smart Queue & Appointment Booking:</strong> Eliminates waiting room overcrowding by generating live queue tracking and automated SMS/app reminders.</li>
          <li><strong>Voice Assistance:</strong> Integrated accessible voice guidance for rural mothers to navigate healthcare steps in vernacular language.</li>
          <li><strong>Health Reports Repository:</strong> Centralized digital diagnostic reports for pediatric follow-ups.</li>
        </ul>

        <div style="background: rgba(255,255,255,0.04); padding: 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); margin-top: 1rem;">
          <strong style="color: #38bdf8;">Technologies Used:</strong> AI Healthcare, Web Portals, Voice Assistive APIs, Queue Systems, Team Collaboration
        </div>
      `
    },
    webdev: {
      title: 'Modern Responsive Web Development Suite',
      subtitle: 'InternCourse Internship • Certificate ID: IC25/10141',
      content: `
        <p><strong>Overview:</strong> Developed during a 1-month professional internship at InternCourse (04 Dec 2025 to 04 Jan 2026). Focused on modern frontend standards, responsive design frameworks, and Git collaboration workflows.</p>
        
        <h4 style="color: #fff; margin: 1.25rem 0 0.5rem;">Key Engineering Highlights:</h4>
        <ul>
          <li><strong>Responsive Layouts:</strong> Implemented fluid Grid and Flexbox architectures adapting across all mobile, tablet, and widescreen displays.</li>
          <li><strong>Interactive UI Components:</strong> Built accessible forms, dynamic modals, toast messaging, and client-side data validations.</li>
          <li><strong>Version Control:</strong> Managed feature branches and team pull requests via Git and GitHub.</li>
          <li><strong>Accreditation:</strong> Verified completion certificate issued with credential ID <em>IC25/10141</em>.</li>
        </ul>

        <div style="background: rgba(255,255,255,0.04); padding: 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); margin-top: 1rem;">
          <strong style="color: #38bdf8;">Technologies Used:</strong> HTML5, CSS3, Modern JavaScript, Git, GitHub
        </div>
      `
    },
    samcore: {
      title: 'Practical Machine Learning & Preprocessing Pipeline',
      subtitle: 'SAMCORE Machine Learning Internship • Data Engineering & Model Training',
      content: `
        <p><strong>Overview:</strong> Executed end-to-end Machine Learning workflows on structured datasets as a Machine Learning Intern at SAMCORE. Focused on practical data engineering, automated preprocessing, supervised model training, and rigorous validation metrics.</p>
        
        <h4 style="color: #fff; margin: 1.25rem 0 0.5rem;">Key Engineering Highlights:</h4>
        <ul>
          <li><strong>Data Cleansing & Transformation:</strong> Addressed skewed distributions, null value imputations, categorical encoding, and standard scaling across complex datasets.</li>
          <li><strong>Feature Engineering:</strong> Extracted high-leverage predictive variables to boost algorithm performance and mitigate multi-collinearity.</li>
          <li><strong>Model Benchmarking:</strong> Trained, validated, and tuned machine learning algorithms using Scikit-Learn; analyzed cross-validation convergence.</li>
          <li><strong>Diagnostics & Interpretability:</strong> Evaluated model performance using confusion matrices, precision, recall, F1-scores, and ROC-AUC curves.</li>
        </ul>

        <div style="background: rgba(255,255,255,0.04); padding: 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08); margin-top: 1rem;">
          <strong style="color: #38bdf8;">Technologies Used:</strong> Python, Scikit-Learn, Pandas, NumPy, Jupyter Notebook, Matplotlib
        </div>
      `
    }
  };

  const detailButtons = document.querySelectorAll('.view-details-btn');

  detailButtons.forEach(button => {
    button.addEventListener('click', () => {
      const projectKey = button.getAttribute('data-project');
      const data = projectDetails[projectKey];

      if (data && projectModal && modalHeader && modalBody) {
        modalHeader.innerHTML = `
          <h3>${data.title}</h3>
          <span class="modal-badge">${data.subtitle}</span>
        `;
        modalBody.innerHTML = data.content;
        projectModal.classList.add('active');
        projectModal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
      }
    });
  });

  function closeModal() {
    if (projectModal) {
      projectModal.classList.remove('active');
      projectModal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  }

  if (modalClose) modalClose.addEventListener('click', closeModal);

  if (projectModal) {
    projectModal.addEventListener('click', (e) => {
      if (e.target === projectModal) closeModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && projectModal && projectModal.classList.contains('active')) {
      closeModal();
    }
  });

  /* --------------------------------------------------------------------------
     5b. Verified Credential Verification Modal System
     -------------------------------------------------------------------------- */
  const credentialDetails = {
    'oracle-ai': {
      title: 'Oracle Cloud Infrastructure 2025 Certified AI Foundations Associate',
      issuer: 'Oracle University • Oracle Corporation',
      date: 'May 20, 2025',
      id: '101592019OCI25AICFA',
      signatory: 'Damien Carey, Senior Vice President, Oracle University',
      badgeColor: '#ef4444',
      badgeIcon: 'fa-solid fa-brain',
      description: 'Official global certification from Oracle Corporation validating foundational concepts of Artificial Intelligence, Machine Learning, Deep Learning, and Generative AI services running on Oracle Cloud Infrastructure.',
      topics: [
        'Fundamentals of Artificial Intelligence & Machine Learning',
        'Deep Learning Architectures & Neural Networks',
        'Large Language Models (LLMs) & Generative AI on OCI',
        'AI Services & Natural Language Processing workflows'
      ]
    },
    'cisco-cyber': {
      title: 'Introduction to Cybersecurity',
      issuer: 'Cisco Networking Academy',
      date: 'July 31, 2025',
      signatory: 'Lynn Bloomer, Director, Cisco Networking Academy',
      badgeColor: '#06b6d4',
      badgeIcon: 'fa-solid fa-shield-halved',
      description: 'Accredited certificate offered through the Cisco Networking Academy program, demonstrating comprehensive understanding of modern cyber threats, defense countermeasures, and network data confidentiality.',
      topics: [
        'Global Cyber Threat Landscape & Vulnerabilities',
        'Confidentiality, Integrity, and Availability (CIA Triad)',
        'Network Defense Strategies & Firewalls',
        'Security Governance, Privacy & Compliance Principles'
      ]
    },
    'aws-dataflair': {
      title: 'Introduction to AWS',
      issuer: 'DataFlair Web Services',
      date: 'December 05, 2025',
      id: '8147C0715D-7A4B6ED858-75A384FC30',
      signatory: 'Rahul Patodi, CEO, DataFlair',
      badgeColor: '#f59e0b',
      badgeIcon: 'fa-brands fa-aws',
      description: 'Industry training certification validating core Amazon Web Services cloud infrastructure concepts, compute, storage, and IAM security paradigms.',
      topics: [
        'Cloud Computing Models & AWS Global Infrastructure',
        'Amazon EC2 Compute & Auto-Scaling Fundamentals',
        'Amazon S3 Storage, Buckets & Lifecycle Policies',
        'AWS Identity & Access Management (IAM) Security'
      ]
    },
    'infosys-ds': {
      title: 'Data Science Course Completion',
      issuer: 'Infosys Springboard',
      date: 'January 2026',
      badgeColor: '#6366f1',
      badgeIcon: 'fa-solid fa-chart-simple',
      description: 'Professional Data Science course completion from Infosys Springboard covering Python data manipulation, exploratory data analysis, and predictive modeling.',
      topics: [
        'Python for Data Science & Numerical Computing',
        'Exploratory Data Analysis (EDA) & Data Visualization',
        'Hypothesis Testing & Statistical Foundations',
        'Supervised & Unsupervised Machine Learning'
      ]
    },
    'powerbi': {
      title: 'Power BI Micro Course',
      issuer: 'Skill Course',
      date: 'January 2026',
      badgeColor: '#f59e0b',
      badgeIcon: 'fa-solid fa-chart-pie',
      description: 'Specialized course in business intelligence dashboard design, DAX formulas, and interactive KPI tracking.',
      topics: [
        'Data Ingestion, Modeling & Star Schema Architecture',
        'Calculated Columns & DAX Measures',
        'Executive Dashboard Design & Interactive Slicers',
        'Visual Storytelling & Business Reporting'
      ]
    },
    'java': {
      title: 'Advanced Java Programming',
      issuer: 'AKTMCET & VEI Technologies Pvt. Ltd.',
      date: 'February 2026',
      badgeColor: '#f43f5e',
      badgeIcon: 'fa-brands fa-java',
      description: 'Value-added corporate training course certificate in advanced Object-Oriented Programming and robust Java software design.',
      topics: [
        'OOP Principles: Inheritance, Polymorphism, Abstraction, Encapsulation',
        'Java Collections Framework (List, Map, Set)',
        'Exception Handling & Multi-threading Basics',
        'Database Connectivity via JDBC'
      ]
    },
    'atal-ai': {
      title: '“Build and Deploy Your Own AI Model” Workshop',
      issuer: 'Atal Incubation Centre – PEC Foundation',
      date: 'February 2026',
      badgeColor: '#8b5cf6',
      badgeIcon: 'fa-solid fa-microchip',
      description: 'Practical hands-on workshop focused on training custom AI models and deploying them into production environments.',
      topics: [
        'Model Prototyping & Pipeline Construction',
        'Containerization & API Wrapping for ML Models',
        'Inference Optimization & Latency Considerations',
        'End-to-End MLOps Lifecycle'
      ]
    },
    'google-cloud': {
      title: 'Google Cloud Engineering Certificate',
      issuer: 'Google Cloud',
      date: 'Certified Competency',
      badgeColor: '#06b6d4',
      badgeIcon: 'fa-brands fa-google',
      description: 'Foundational cloud engineering credentials validating Google Cloud Platform computing, network architecture, and resource management.',
      topics: [
        'Google Compute Engine (GCE) & Virtual Machines',
        'Google Cloud Storage (GCS) Buckets & Security',
        'Virtual Private Cloud (VPC) Networking',
        'IAM Roles, Service Accounts & Billing Controls'
      ]
    },
    'tcs-nqt': {
      title: 'TCS iON National Qualifier Test (NQT)',
      issuer: 'Tata Consultancy Services',
      date: 'Qualified',
      id: 'Score: 59.70',
      badgeColor: '#10b981',
      badgeIcon: 'fa-solid fa-award',
      description: 'Standardized national employability assessment conducted by Tata Consultancy Services evaluating cognitive skills, problem-solving, and numerical reasoning.',
      topics: [
        'Numerical Ability & Quantitative Analysis',
        'Reasoning & Logical Problem Solving',
        'Verbal Ability & Technical Communication',
        'Algorithmic Logic Evaluation'
      ]
    },
    'hdca': {
      title: 'HDCA Programming Certification',
      issuer: 'Honours Diploma in Computer Applications',
      date: 'Completed',
      badgeColor: '#06b6d4',
      badgeIcon: 'fa-solid fa-laptop-code',
      description: 'Comprehensive software development diploma certifying foundational programming proficiency in Python, HTML5, CSS3, and relational databases.',
      topics: [
        'Python Programming & Control Flow',
        'Relational Databases & MySQL Query Execution',
        'Frontend Architecture (HTML5 & CSS3)',
        'Applied Computer Science Foundations'
      ]
    },
    'nptel-cloud': {
      title: 'Cloud Computing Certification',
      issuer: 'NPTEL (Ministry of Education)',
      date: 'In Progress (Active Enrollment)',
      badgeColor: '#38bdf8',
      badgeIcon: 'fa-solid fa-cloud-arrow-up',
      description: 'Academic certification course covering distributed systems, virtualization layers, and cloud infrastructure architectures.',
      topics: [
        'Distributed Systems Architecture',
        'Hardware & Hypervisor Virtualization',
        'Cloud Service & Deployment Models (IaaS, PaaS, SaaS)',
        'Scalability, Fault Tolerance & Cloud Economics'
      ]
    }
  };

  const credentialModal = document.getElementById('credential-modal');
  const credentialHeader = document.getElementById('credential-modal-header');
  const credentialBody = document.getElementById('credential-modal-body');
  const credentialClose = document.getElementById('credential-modal-close');

  function openCredential(certKey) {
    const data = credentialDetails[certKey];
    if (!data || !credentialModal || !credentialHeader || !credentialBody) return;

    credentialHeader.innerHTML = `
      <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 0.5rem;">
        <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; color: ${data.badgeColor};">
          <i class="${data.badgeIcon}"></i>
        </div>
        <div>
          <h3 style="color: #fff; font-size: 1.25rem; line-height: 1.3;">${data.title}</h3>
          <span style="color: var(--text-muted); font-size: 0.9rem;">${data.issuer}</span>
        </div>
      </div>
    `;

    let idRow = '';
    if (data.id) {
      idRow = `
        <div style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.25); padding: 0.75rem 1rem; border-radius: 8px; display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.25rem;">
          <div>
            <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-dim); display: block;">Official Credential ID / Score</span>
            <code style="font-size: 0.95rem; color: #38bdf8; font-family: var(--font-mono); font-weight: 600;">${data.id}</code>
          </div>
          <button class="btn btn-outline btn-sm dyn-copy-btn" data-copy="${data.id}" title="Copy Credential ID" style="padding: 0.35rem 0.75rem;">
            <i class="fa-regular fa-copy"></i>
            <span>Copy</span>
          </button>
        </div>
      `;
    }

    let signatoryRow = '';
    if (data.signatory) {
      signatoryRow = `<p style="margin-bottom: 0.5rem;"><strong style="color: var(--text-main);">Authority / Signatory:</strong> <span style="color: var(--text-muted);">${data.signatory}</span></p>`;
    }

    let topicsHtml = data.topics.map(t => `<li style="margin-bottom: 0.4rem; display: flex; align-items: flex-start; gap: 0.6rem;"><i class="fa-solid fa-circle-check text-cyan" style="margin-top: 0.25rem; font-size: 0.85rem;"></i><span>${t}</span></li>`).join('');

    credentialBody.innerHTML = `
      ${idRow}
      <p style="margin-bottom: 0.6rem;"><strong style="color: var(--text-main);">Issue Date / Status:</strong> <span style="color: var(--text-muted);">${data.date}</span></p>
      ${signatoryRow}
      <p style="margin-bottom: 1.25rem; color: var(--text-muted); line-height: 1.6;">${data.description}</p>
      <h4 style="color: #fff; margin-bottom: 0.75rem; font-size: 1rem;">Validated Competencies & Topics:</h4>
      <ul style="list-style: none; padding-left: 0; color: var(--text-muted); font-size: 0.95rem; margin-bottom: 1.5rem;">
        ${topicsHtml}
      </ul>
      <div style="display: flex; gap: 0.75rem; justify-content: flex-end;">
        <button class="btn btn-primary btn-sm" id="btn-close-credential-modal">Done</button>
      </div>
    `;

    credentialModal.classList.add('active');
    credentialModal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';

    // attach listener to close button inside modal
    const innerClose = document.getElementById('btn-close-credential-modal');
    if (innerClose) innerClose.addEventListener('click', closeCredentialModal);

    // attach listener to dynamically injected copy button
    const dynCopy = credentialBody.querySelector('.dyn-copy-btn');
    if (dynCopy) {
      dynCopy.addEventListener('click', () => {
        const text = dynCopy.getAttribute('data-copy');
        if (text) {
          navigator.clipboard.writeText(text).then(() => {
            showToast(`Copied "${text}" to clipboard!`);
          });
        }
      });
    }
  }

  function closeCredentialModal() {
    if (credentialModal) {
      credentialModal.classList.remove('active');
      credentialModal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  }

  if (credentialClose) credentialClose.addEventListener('click', closeCredentialModal);
  if (credentialModal) {
    credentialModal.addEventListener('click', (e) => {
      if (e.target === credentialModal) closeCredentialModal();
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && credentialModal && credentialModal.classList.contains('active')) {
      closeCredentialModal();
    }
  });

  document.querySelectorAll('.view-credential-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const certKey = btn.getAttribute('data-cert');
      openCredential(certKey);
    });
  });

  document.querySelectorAll('.cert-card[data-cert]').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('.copy-action') || e.target.closest('a') || e.target.closest('.view-credential-btn')) return;
      const certKey = card.getAttribute('data-cert');
      openCredential(certKey);
    });
  });

  /* --------------------------------------------------------------------------
     6. Toast Notification & Copy-to-Clipboard
     -------------------------------------------------------------------------- */
  const toast = document.getElementById('toast');
  const toastMessage = document.getElementById('toast-message');
  let toastTimer = null;

  function showToast(message, isSuccess = true) {
    if (!toast || !toastMessage) return;

    toastMessage.textContent = message;
    const icon = toast.querySelector('.toast-icon');
    if (icon) {
      icon.className = isSuccess ? 'fa-solid fa-check-circle toast-icon' : 'fa-solid fa-circle-exclamation toast-icon';
      icon.style.color = isSuccess ? '#34d399' : '#f43f5e';
    }

    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove('show');
    }, 3200);
  }

  const copyElements = document.querySelectorAll('.copy-action');
  copyElements.forEach(el => {
    el.addEventListener('click', () => {
      const textToCopy = el.getAttribute('data-copy');
      if (textToCopy) {
        navigator.clipboard.writeText(textToCopy).then(() => {
          showToast(`Copied "${textToCopy}" to clipboard!`);
        }).catch(() => {
          showToast('Failed to copy. Please copy manually.', false);
        });
      }
    });
  });

  const btnCopyNav = document.getElementById('btn-copy-email-nav');
  if (btnCopyNav) {
    btnCopyNav.addEventListener('click', () => {
      navigator.clipboard.writeText('aakshebiofficial@gmail.com').then(() => {
        showToast('Copied email (aakshebiofficial@gmail.com) to clipboard!');
      });
    });
  }

  /* --------------------------------------------------------------------------
     7. Contact Form Submission
     -------------------------------------------------------------------------- */
  const contactForm = document.getElementById('contact-form');
  const submitBtn = document.getElementById('form-submit-btn');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = document.getElementById('form-name').value.trim();
      const email = document.getElementById('form-email').value.trim();
      const subject = document.getElementById('form-subject').value.trim();
      const message = document.getElementById('form-message').value.trim();

      if (!name || !email || !message) {
        showToast('Please complete all required fields.', false);
        return;
      }

      // UI Loading State
      if (submitBtn) {
        const originalHtml = submitBtn.innerHTML;
        submitBtn.innerHTML = `<span>Sending...</span> <i class="fa-solid fa-spinner fa-spin"></i>`;
        submitBtn.disabled = true;

        setTimeout(() => {
          submitBtn.innerHTML = `<span>Message Sent!</span> <i class="fa-solid fa-check"></i>`;
          showToast(`Thank you ${name}! Your inquiry has been sent.`);
          contactForm.reset();

          // Prepare mailto fallback link in new tab if user wants to open their email client
          const mailtoUrl = `mailto:aakshebiofficial@gmail.com?subject=${encodeURIComponent(subject || 'Portfolio Inquiry')}&body=${encodeURIComponent(`Hi Aakash,\n\nMy name is ${name} (${email}).\n\n${message}`)}`;
          
          setTimeout(() => {
            submitBtn.innerHTML = originalHtml;
            submitBtn.disabled = false;
            window.location.href = mailtoUrl;
          }, 1200);
        }, 800);
      }
    });
  }

  /* --------------------------------------------------------------------------
     8. Interactive Neural Network / Particle Canvas
     -------------------------------------------------------------------------- */
  const canvas = document.getElementById('neural-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    let mouse = { x: null, y: null, radius: 150 };

    window.addEventListener('mousemove', (e) => {
      mouse.x = e.x;
      mouse.y = e.y;
    });

    window.addEventListener('mouseout', () => {
      mouse.x = null;
      mouse.y = null;
    });

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      initParticles();
    });

    const particles = [];
    const particleCount = Math.min(65, Math.floor((width * height) / 18000));

    class Particle {
      constructor() {
        this.x = Math.random() * width;
        this.y = Math.random() * height;
        this.vx = (Math.random() - 0.5) * 0.7;
        this.vy = (Math.random() - 0.5) * 0.7;
        this.radius = Math.random() * 2 + 1;
        this.baseColor = Math.random() > 0.4 ? 'rgba(99, 102, 241, ' : 'rgba(6, 182, 212, ';
      }

      update() {
        this.x += this.vx;
        this.y += this.vy;

        if (this.x < 0 || this.x > width) this.vx *= -1;
        if (this.y < 0 || this.y > height) this.vy *= -1;

        // Mouse interaction
        if (mouse.x !== null && mouse.y !== null) {
          const dx = mouse.x - this.x;
          const dy = mouse.y - this.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < mouse.radius) {
            const force = (mouse.radius - dist) / mouse.radius;
            this.x -= (dx / dist) * force * 2;
            this.y -= (dy / dist) * force * 2;
          }
        }
      }

      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = this.baseColor + '0.7)';
        ctx.fill();
      }
    }

    function initParticles() {
      particles.length = 0;
      for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
      }
    }

    initParticles();

    function connectParticles() {
      for (let a = 0; a < particles.length; a++) {
        for (let b = a + 1; b < particles.length; b++) {
          const dx = particles[a].x - particles[b].x;
          const dy = particles[a].y - particles[b].y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 130) {
            const opacity = (1 - distance / 130) * 0.25;
            ctx.strokeStyle = `rgba(99, 102, 241, ${opacity})`;
            ctx.lineWidth = 0.8;
            ctx.beginPath();
            ctx.moveTo(particles[a].x, particles[a].y);
            ctx.lineTo(particles[b].x, particles[b].y);
            ctx.stroke();
          }
        }
      }
    }

    function animateCanvas() {
      ctx.clearRect(0, 0, width, height);
      for (let i = 0; i < particles.length; i++) {
        particles[i].update();
        particles[i].draw();
      }
      connectParticles();
      requestAnimationFrame(animateCanvas);
    }

    animateCanvas();
  }

  /* --------------------------------------------------------------------------
     9. AI & Analytics Interactive Playground Logic
     -------------------------------------------------------------------------- */
  // Tab Switcher
  const tabBtnDisease = document.getElementById('tab-btn-disease');
  const tabBtnCloud = document.getElementById('tab-btn-cloud');
  const panelDisease = document.getElementById('disease-tab');
  const panelCloud = document.getElementById('cloud-tab');

  if (tabBtnDisease && tabBtnCloud && panelDisease && panelCloud) {
    tabBtnDisease.addEventListener('click', () => {
      tabBtnDisease.classList.add('active');
      tabBtnCloud.classList.remove('active');
      panelDisease.style.display = 'block';
      panelCloud.style.display = 'none';
    });

    tabBtnCloud.addEventListener('click', () => {
      tabBtnCloud.classList.add('active');
      tabBtnDisease.classList.remove('active');
      panelCloud.style.display = 'block';
      panelDisease.style.display = 'none';
      updateCloudCalculations(); // recalculate on switch
    });
  }

  // --- Healthcare Disease Predictor Logic ---
  const inputAge = document.getElementById('input-age');
  const inputGlucose = document.getElementById('input-glucose');
  const inputBp = document.getElementById('input-bp');
  const inputBmi = document.getElementById('input-bmi');

  const valAge = document.getElementById('val-age');
  const valGlucose = document.getElementById('val-glucose');
  const valBp = document.getElementById('val-bp');
  const valBmi = document.getElementById('val-bmi');

  const gaugeCircle = document.getElementById('disease-gauge-circle');
  const gaugeScore = document.getElementById('disease-risk-score');
  const statusBadge = document.getElementById('disease-status-badge');
  const statusText = document.getElementById('disease-status-text');
  const summaryText = document.getElementById('disease-summary-text');

  const barGlucose = document.getElementById('bar-glucose');
  const textBarGlucose = document.getElementById('text-bar-glucose');
  const barBp = document.getElementById('bar-bp');
  const textBarBp = document.getElementById('text-bar-bp');
  const barBmi = document.getElementById('bar-bmi');
  const textBarBmi = document.getElementById('text-bar-bmi');
  const barAge = document.getElementById('bar-age');
  const textBarAge = document.getElementById('text-bar-age');

  function calculateDiseaseRisk() {
    if (!inputAge || !inputGlucose || !inputBp || !inputBmi) return;

    const age = parseFloat(inputAge.value);
    const glucose = parseFloat(inputGlucose.value);
    const bp = parseFloat(inputBp.value);
    const bmi = parseFloat(inputBmi.value);

    // Update displayed values
    if (valAge) valAge.textContent = `${age} yrs`;
    if (valGlucose) valGlucose.textContent = `${glucose} mg/dL`;
    if (valBp) valBp.textContent = `${bp} mmHg`;
    if (valBmi) valBmi.textContent = `${bmi.toFixed(1)}`;

    // Component risk calculations (normalized to 0-1)
    let glucoseScore = 0;
    if (glucose <= 100) glucoseScore = (glucose - 70) / 150;
    else if (glucose <= 125) glucoseScore = 0.25 + ((glucose - 100) / 25) * 0.35;
    else glucoseScore = 0.60 + Math.min(0.40, ((glucose - 125) / 125) * 0.40);

    let bpScore = 0;
    if (bp <= 120) bpScore = (bp - 90) / 150;
    else if (bp <= 139) bpScore = 0.25 + ((bp - 120) / 19) * 0.35;
    else bpScore = 0.60 + Math.min(0.40, ((bp - 140) / 50) * 0.40);

    let bmiScore = 0;
    if (bmi <= 24.9) bmiScore = (bmi - 18) / 35;
    else if (bmi <= 29.9) bmiScore = 0.25 + ((bmi - 25) / 5) * 0.35;
    else bmiScore = 0.60 + Math.min(0.40, ((bmi - 30) / 15) * 0.40);

    let ageScore = Math.min(1.0, Math.max(0.1, (age - 18) / 67));

    // Weighted ensemble probability
    const weightedProb = (glucoseScore * 0.40 + bpScore * 0.25 + bmiScore * 0.25 + ageScore * 0.10);
    const riskPercent = Math.min(99, Math.max(4, Math.round(weightedProb * 100)));

    // Update Circular Gauge
    if (gaugeScore) gaugeScore.textContent = `${riskPercent}%`;
    if (gaugeCircle) {
      const circumference = 314.16; // 2 * pi * 50
      const offset = circumference - (riskPercent / 100) * circumference;
      gaugeCircle.style.strokeDashoffset = offset;

      if (riskPercent < 35) {
        gaugeCircle.style.stroke = '#34d399'; // emerald
      } else if (riskPercent < 65) {
        gaugeCircle.style.stroke = '#fbbf24'; // amber
      } else {
        gaugeCircle.style.stroke = '#f43f5e'; // rose
      }
    }

    // Update Status Badge & Summary
    if (statusBadge && statusText && summaryText) {
      if (riskPercent < 35) {
        statusBadge.className = 'diagnosis-status-badge status-low';
        statusBadge.innerHTML = '<i class="fa-solid fa-shield-heart"></i> <span>Low Risk Profile</span>';
        summaryText.textContent = 'Biomarkers are within optimal clinical thresholds. Blood glucose and systolic pressure suggest stable metabolic balance.';
      } else if (riskPercent < 65) {
        statusBadge.className = 'diagnosis-status-badge status-moderate';
        statusBadge.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> <span>Moderate Risk (Watchlist)</span>';
        summaryText.textContent = 'Elevated biomarker variance detected. Mild systolic pressure or fasting glucose levels suggest lifestyle and dietary intervention.';
      } else {
        statusBadge.className = 'diagnosis-status-badge status-high';
        statusBadge.innerHTML = '<i class="fa-solid fa-radiation"></i> <span>Elevated Risk Alert</span>';
        summaryText.textContent = 'High probability of cardiometabolic risk detected. Model confidence suggests prompt clinical follow-up and diagnostic evaluation.';
      }
    }

    // Dynamic Feature Contributions
    const totalRaw = (glucoseScore * 40) + (bpScore * 25) + (bmiScore * 25) + (ageScore * 10) || 1;
    const pGlucose = Math.round((glucoseScore * 40 / totalRaw) * 100);
    const pBp = Math.round((bpScore * 25 / totalRaw) * 100);
    const pBmi = Math.round((bmiScore * 25 / totalRaw) * 100);
    const pAge = Math.max(1, 100 - (pGlucose + pBp + pBmi));

    if (barGlucose && textBarGlucose) {
      barGlucose.style.width = `${pGlucose}%`;
      textBarGlucose.textContent = `${pGlucose}%`;
    }
    if (barBp && textBarBp) {
      barBp.style.width = `${pBp}%`;
      textBarBp.textContent = `${pBp}%`;
    }
    if (barBmi && textBarBmi) {
      barBmi.style.width = `${pBmi}%`;
      textBarBmi.textContent = `${pBmi}%`;
    }
    if (barAge && textBarAge) {
      barAge.style.width = `${pAge}%`;
      textBarAge.textContent = `${pAge}%`;
    }
  }

  [inputAge, inputGlucose, inputBp, inputBmi].forEach(slider => {
    if (slider) slider.addEventListener('input', calculateDiseaseRisk);
  });

  // Disease Presets
  const btnDiseaseNormal = document.getElementById('preset-disease-normal');
  const btnDiseaseBorderline = document.getElementById('preset-disease-borderline');
  const btnDiseaseHigh = document.getElementById('preset-disease-high');

  if (btnDiseaseNormal) {
    btnDiseaseNormal.addEventListener('click', () => {
      inputAge.value = 28;
      inputGlucose.value = 92;
      inputBp.value = 118;
      inputBmi.value = 22.4;
      calculateDiseaseRisk();
    });
  }

  if (btnDiseaseBorderline) {
    btnDiseaseBorderline.addEventListener('click', () => {
      inputAge.value = 46;
      inputGlucose.value = 122;
      inputBp.value = 136;
      inputBmi.value = 27.8;
      calculateDiseaseRisk();
    });
  }

  if (btnDiseaseHigh) {
    btnDiseaseHigh.addEventListener('click', () => {
      inputAge.value = 62;
      inputGlucose.value = 195;
      inputBp.value = 168;
      inputBmi.value = 34.2;
      calculateDiseaseRisk();
    });
  }

  // --- FinOps Cloud Cost Optimizer Logic ---
  const inputInstances = document.getElementById('input-instances');
  const inputUtilization = document.getElementById('input-utilization');
  const inputDisks = document.getElementById('input-disks');
  const providerPills = document.querySelectorAll('.provider-pill');

  const valInstances = document.getElementById('val-instances');
  const valUtilization = document.getElementById('val-utilization');
  const valDisks = document.getElementById('val-disks');

  const statMonthly = document.getElementById('finops-monthly-savings');
  const statAnnual = document.getElementById('finops-annual-savings');
  const statIdle = document.getElementById('finops-idle-instances');
  const statStorageWaste = document.getElementById('finops-storage-waste');
  const statEfficiency = document.getElementById('finops-efficiency');
  const recomList = document.getElementById('recom-list');

  let currentProviderRate = 1.0;

  providerPills.forEach(pill => {
    pill.addEventListener('click', () => {
      providerPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      currentProviderRate = parseFloat(pill.getAttribute('data-rate')) || 1.0;
      updateCloudCalculations();
    });
  });

  function updateCloudCalculations() {
    if (!inputInstances || !inputUtilization || !inputDisks) return;

    const instances = parseInt(inputInstances.value, 10);
    const utilization = parseInt(inputUtilization.value, 10);
    const disks = parseInt(inputDisks.value, 10);

    if (valInstances) valInstances.textContent = `${instances} Nodes`;
    if (valUtilization) valUtilization.textContent = `${utilization}%`;
    if (valDisks) valDisks.textContent = `${disks} Disks`;

    const underutilizedRatio = Math.max(0.05, (100 - utilization) / 100);
    const idleNodes = Math.round(instances * underutilizedRatio * 0.52);

    const computeSavings = idleNodes * 76 * currentProviderRate;
    const storageSavings = disks * 18 * currentProviderRate;

    const totalMonthly = Math.round(computeSavings + storageSavings);
    const totalAnnual = totalMonthly * 12;

    const efficiencyScore = Math.min(98, Math.max(14, Math.round(utilization * 0.95 + (1 - Math.min(disks, 50) / 100) * 15)));

    if (statMonthly) statMonthly.textContent = `$${totalMonthly.toLocaleString()}`;
    if (statAnnual) statAnnual.textContent = `≈ $${totalAnnual.toLocaleString()} / year`;
    if (statIdle) statIdle.textContent = `${idleNodes} Nodes`;
    if (statStorageWaste) statStorageWaste.textContent = `$${Math.round(storageSavings).toLocaleString()} / mo`;
    if (statEfficiency) statEfficiency.textContent = `${efficiencyScore}%`;

    if (recomList) {
      recomList.innerHTML = `
        <li><i class="fa-solid fa-circle-check text-emerald"></i> Downsize or hibernate <strong>${idleNodes} low-utilization nodes</strong> to burstable instances (Save ~$${Math.round(computeSavings).toLocaleString()}/mo).</li>
        <li><i class="fa-solid fa-circle-check text-emerald"></i> Purge / snapshot <strong>${disks} orphaned unattached storage volumes</strong> (Save ~$${Math.round(storageSavings).toLocaleString()}/mo).</li>
        <li><i class="fa-solid fa-circle-check text-emerald"></i> Target fleet efficiency improvement from current <strong>${efficiencyScore}%</strong> to <strong>85%+</strong> via auto-scaling policies.</li>
      `;
    }
  }

  [inputInstances, inputUtilization, inputDisks].forEach(slider => {
    if (slider) slider.addEventListener('input', updateCloudCalculations);
  });

  // Cloud Presets
  const btnCloudStartup = document.getElementById('preset-cloud-startup');
  const btnCloudMedium = document.getElementById('preset-cloud-medium');
  const btnCloudEnterprise = document.getElementById('preset-cloud-enterprise');

  if (btnCloudStartup) {
    btnCloudStartup.addEventListener('click', () => {
      inputInstances.value = 15;
      inputUtilization.value = 45;
      inputDisks.value = 3;
      updateCloudCalculations();
    });
  }

  if (btnCloudMedium) {
    btnCloudMedium.addEventListener('click', () => {
      inputInstances.value = 50;
      inputUtilization.value = 18;
      inputDisks.value = 14;
      updateCloudCalculations();
    });
  }

  if (btnCloudEnterprise) {
    btnCloudEnterprise.addEventListener('click', () => {
      inputInstances.value = 180;
      inputUtilization.value = 11;
      inputDisks.value = 42;
      updateCloudCalculations();
    });
  }

  // Initial calculation runs
  calculateDiseaseRisk();
  updateCloudCalculations();

  /* --------------------------------------------------------------------------
     10. Executive Resume Modal Handlers
     -------------------------------------------------------------------------- */
  const resumeModal = document.getElementById('resume-modal');
  const resumeModalClose = document.getElementById('resume-modal-close');
  const btnOpenResumeNav = document.getElementById('btn-open-resume-nav');
  const btnOpenResumeMobile = document.getElementById('btn-open-resume-mobile');
  const heroResumeBtn = document.getElementById('hero-resume-btn');

  function openResumeModal() {
    if (resumeModal) {
      resumeModal.classList.add('active');
      resumeModal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeResumeModal() {
    if (resumeModal) {
      resumeModal.classList.remove('active');
      resumeModal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  }

  if (btnOpenResumeNav) btnOpenResumeNav.addEventListener('click', openResumeModal);
  if (btnOpenResumeMobile) btnOpenResumeMobile.addEventListener('click', () => {
    const mobileDrawer = document.getElementById('mobile-drawer');
    if (mobileDrawer) mobileDrawer.classList.remove('open');
    openResumeModal();
  });
  if (heroResumeBtn) heroResumeBtn.addEventListener('click', openResumeModal);
  if (resumeModalClose) resumeModalClose.addEventListener('click', closeResumeModal);

  if (resumeModal) {
    resumeModal.addEventListener('click', (e) => {
      if (e.target === resumeModal) closeResumeModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && resumeModal && resumeModal.classList.contains('active')) {
      closeResumeModal();
    }
  });
});
